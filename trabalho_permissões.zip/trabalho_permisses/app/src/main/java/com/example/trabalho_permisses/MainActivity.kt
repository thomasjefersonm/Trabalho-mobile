package com.example.trabalho_permisses

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    PermissionScreen()
                }
            }
        }
    }
}

@Composable
fun PermissionScreen() {
    val context = LocalContext.current
    var statusTexto by remember { mutableStateOf("Permissao ainda nao solicitada.") }
    var localizacaoTexto by remember { mutableStateOf("") }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { concedida: Boolean ->
        if (concedida) {
            statusTexto = "Permissao concedida!"
            localizacaoTexto = obterLocalizacaoCorreta(context)
        } else {
            statusTexto = "Permissao negada pelo usuario."
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Demonstracao: Permissoes em tempo de execucao", style = MaterialTheme.typography.titleLarge)

        Text(statusTexto)
        if (localizacaoTexto.isNotEmpty()) {
            Text(localizacaoTexto)
        }

        Button(onClick = {
            val jaTemPermissao = ContextCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

            if (jaTemPermissao) {
                statusTexto = "Ja tinhamos permissao."
                localizacaoTexto = obterLocalizacaoCorreta(context)
            } else {
                permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }) {
            Text("Solicitar localizacao")
        }

        HorizontalDivider()

        // Caminho manual real: usuário revoga a permissão na tela do sistema.
        Button(onClick = {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
            }
            context.startActivity(intent)
        }) {
            Text("Abrir tela de permissoes do app (manual)")
        }
    }
}

@SuppressLint("MissingPermission")
fun obterLocalizacaoCorreta(context: Context): String {
    val temPermissao = ContextCompat.checkSelfPermission(
        context, Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED

    if (!temPermissao) return "Sem permissao para acessar localizacao."

    val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val location: Location? = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        ?: locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)

    return if (location != null) {
        "Latitude: ${location.latitude}, Longitude: ${location.longitude}"
    } else {
        "Localizacao indisponivel (ligue o GPS no emulador)."
    }
}